
  Test_LPGPCA.m --- An example of the PCA-based denoising program for gray image. 

  Test_LPGPCA_Color.m --- An example of the PCA-based denoising program for full color image.